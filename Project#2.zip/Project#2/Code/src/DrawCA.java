import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.util.Random;

import javax.swing.*;
/*****************************************************************************************/
/** This class draws a celluar automta based on a give ruleset and inital configuration **/
/** only can be used for rules and configs of length 149.                              **/
/*****************************************************************************************/
public class DrawCA extends JPanel {

	/****************************************************************************************
	 * /* Global Variables /
	 ****************************************************************************************/

	private int width = 800; // width of jframe window
	private int height = 500; // height of jfram window

	int config[] = new int[149];

	int initial[] = { 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 0,
			0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 0, 0, 0, 0, 0,
			1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0,
			0, 0, 1, 0, 0, 0, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
			0, 1, 1, 1, 1, 1, 1, 0 };

	int maxfitrule[] = { 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0,
			0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 1, 1, 0, 1, 1, 1, 0, 1, 1, 0, 1, 1, 1,
			1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 0, 0, 1, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1,
			1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 0, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1 };

	int unfitrule[] = { 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0,
			0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1,
			1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
			1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1 };

	/***************************************************************************************
	 *
	 * @param g
	 *            /
	 ***************************************************************************************/
	@Override
	protected void paintComponent(Graphics g) {

		super.paintComponent(g);
		displayCA(g);

	}

	/***************************************************************************************
	 * /* / * @return the size of the window /
	 ***************************************************************************************/
	@Override
	public Dimension getPreferredSize() {
		// so that our GUI is big enough
		return new Dimension(width, height);
	}

	/***************************************************************************************
	 * /* create the GUI that will display CA /* Currently there is a bug if you
	 * resize the window a new generation will be populated /* So for now i took
	 * away the ability to resize the frame, will look into more later /* /
	 ***************************************************************************************/
	// create the GUI explicitly on the Swing event thread
	private static void createAndShowGui() {
		DrawCA mainPanel = new DrawCA();

		JFrame frame = new JFrame("CA");
		frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
		frame.getContentPane().add(mainPanel);
		frame.pack();
		frame.setLocationByPlatform(true);
		frame.setResizable(false);
		frame.setVisible(true);
	}


    /**********************************************/
	/** generate a random initial configuration **/
	/*********************************************/
	void createRandomConfiguration(int[] config) {
		Random rand = new Random();

		for (int i = 0; i < 149; i++) {
			int x = rand.nextInt(2);
			config[i] = x;
		}
	}
	
	/**********************************************************************************************
	 *
	 * @param g
	 *            This method is straight forward: 1. Loop through the grid looking
	 *            for either a 0 or 1 2. If 0 draw a a white rectangle, 1 draw a
	 *            black rectangle at current i position in matrix /
	 ********************************************************************************************/
	void displayCA(Graphics g) {
		createRandomConfiguration(config);
		CA ca = new CA(maxfitrule, config);
		for (int j = 1; j < ca.MAXTIMESTEPS; j++) {
			for (int i = 0; i < ca.CELLPOPULATIONSIZE; i++) {
				if (ca.matrix[j][i] == 1) {
					g.setColor(Color.BLACK);
				}

				else {
					g.setColor(Color.WHITE);
				}
				g.drawRect(i * 3, j * 3, 3, 3);
			}
		}

	}

	/************************************************************************
	 * Main Function
	 * 
	 * @param args
	 *************************************************************************/
	public static void main(String[] args) {

		SwingUtilities.invokeLater(new Runnable() {
			@Override
			public void run() {
				createAndShowGui();

			}
		});

	}

}