# CS 423 Spring 2018 Project 2 CS 423 
# John Krukar
# Brandon Wade

Within in the src you will find 9 different classes. 

1. CA.java that checks neighbors within a radius of 2
2. CA2R.java that checks neighbors within a radius of 3
3. DrawCA.java that will draw the end result of a CA (havent tested it with CA2R)
4. GenecticAlgorithm.java uses a GA to evolve the CA made from CA.java
5. GenecticAlgorithm.2java uses a GA to evolve the CA made from CA2.java
6. inverseCA2R.java that does the opposite of CA.java meaning instead of all the cells turning black if a '1' is read it will turn white.
7. NeutralNetwork.java creates a genetic network from lambda and fitness values. Each node represents a different rule set(phenotype)
8. Node.java defines what a node represents in the NutralNetwork
9. RuleSet.java calculates fitness and lambda values of a rule set

Getting Started

The three classes that contain Main i.e are able to be ran are

* DrawCA.java

- Currently the DrawCA class is set to display a CA with a ruleset that is shown to have the best fitness. This ruleset is called is a global variable called "maxfitrule" directly below you will another ruleset called "unfitrule" that can be used to see a CA with a low fitness value. Just modify the constructor in the function "displayCA" i.e
CA ca = new CA(maxfitrule, config); or
CA ca = new CA(unfitrule, config);

* GeneticAlgortihm.java & GeneticAlgorithm2R.java

These classes will print out on to the command line a string in the form of :

Generation, Fitness, Lambda, Cells

Currently these functions are set to be ran for 320 generations but can easily be changed by modifying:

ArrayList<ArrayList<RuleSet>> generationRuleSets = new ArrayList<>(320);

* Node.java & NeuralNetwork.java
 - These classes currently print out nothing as they require the Jgraphx jar file. They were used to generate the neural network figures found in our paper.

Built With

 * Eclisple 
 * Jgraphx (optional)

 Side Notes

 The excel sheet neutralOut2 gives detailed information on our neural networks retrieved from the NeuralNetwork.java and Node.java classes.


